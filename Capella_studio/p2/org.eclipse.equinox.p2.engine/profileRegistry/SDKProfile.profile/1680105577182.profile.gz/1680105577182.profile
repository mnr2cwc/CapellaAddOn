<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='SDKProfile' timestamp='1680105577182'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/jenkins/agent/workspace/Capella-studio_master/releng/plugins/org.polarsys.capella.studio.releng.product/target/products/org.polarsys.capella.studio.releng.product/win32/win32/x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/jenkins/agent/workspace/Capella-studio_master/releng/plugins/org.polarsys.capella.studio.releng.product/target/products/org.polarsys.capella.studio.releng.product/win32/win32/x86_64'/>
  </properties>
</profile>
